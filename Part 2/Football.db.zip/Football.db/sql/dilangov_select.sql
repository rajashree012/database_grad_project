use dilangov
tee log/dilangov_select_log.txt
select * from team;
select * from player;
select * from matches;                    
select * from stadium;
select * from world_cup;
select * from world_cup_played_by_player;
select * from match_played_by;
select * from goal_and_player_scores_goals;
select * from team_participates_in_world_cup;


