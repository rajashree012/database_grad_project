use dilangov
tee log/team_insert_log.txt
source sql/team_insert.sql

tee log/world_cup_insert_log.txt
source sql/world_cup_insert.sql

tee log/player_insert_log.txt
source sql/player_insert.sql

tee log/stadium_insert_log.txt
source sql/stadium_insert.sql

tee log/matches_insert_log.txt                    
source sql/matches_insert.sql   

tee log/world_cup_played_by_player_insert_log.txt
source sql/world_cup_played_by_player_insert.sql

tee log/match_played_by_insert_log.txt
source sql/match_played_by_insert.sql

tee log/goal_and_player_scores_goals_insert_log.txt
source sql/goal_and_player_scores_goals_insert.sql

tee log/team_participates_in_world_cup_insert_log.txt
source sql/team_participates_in_world_cup_insert.sql










