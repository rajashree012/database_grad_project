import ConfigParser
import random
from lib import match_parse, match_played_by_parse, match_filepaths, getCountryCodeDict
	
# filling the match table
def match_stadium_parse_into_table(match_path,match_op_path,stadium_op_path):
	# loading country codes for country name into dictionary from pickle dump
	country_country_code_dict = getCountryCodeDict()
	# these are few exception cases
	alternate_names=dict()
	alternate_names['germany']='deutschland'
	alternate_names['trinidad and tobago']='trinidad tobago'
	alternate_names['spain']='espana'
	alternate_names['c te d ivoire']='cote d ivoire'
	alternate_names['c\xc3\xb4te d\'ivoire']='cote d ivoire'
	alternate_names['serbia and montenegro']='serbia'
	alternate_names['bosniaherzegovina'] = 'bosnia herzegovina'
	
	f2=open(match_op_path, 'w')
	f2.truncate()  
	f2.close()
	
	f3=open(stadium_op_path, 'w')
	f3.truncate()  
	f3.close()
	
	# create dictionary for year : (winner,runnerup)
	year_runnerup_winner = {}

	# create list of (match_no,year,country_code,country_score,decision)
	match_year_country = []
	distinct_stadium=[]
	for path in match_filepaths(match_path) :
		f=open(path, 'r')          
		lines= f.readlines()
		f.close() 
		
		# choosing the starting point in the file different for cup.txt and cup_finals.txt
		start=0;
		c=0;
		
		if path.split('\\')[-1] == 'cup.txt' :
			for line in lines:
				if(line.strip().startswith('(1)')):
					start=c;
					break;
				c=c+1 
			
		if path.split('\\')[-1] == 'cup_finals.txt' :
			for line in lines:
				if(line.strip().startswith('(')):
					start=c;
					break;
				c=c+1 
		#print path
		# year
		if len(path.split('\\')) > 0 :
			year = path.split('\\')[-2].split('-')[0]
			
		else :
			year = path.split('/')[-2].split('-')[0]
			
		setflag = 0
		c = 0
		# start processing each line
		for line in lines:
			line = line.rstrip('\n')
			# trying to find winner and runner up for an year
			if line.startswith('final') or line.startswith('Final'):
				setflag = 1
			if(c>= start and line.startswith('(')):
				
				linetemp=line.split();
				
				# extracting match number
				match_no = linetemp[0]
				match_no = match_no.replace('(', '')
				match_no = match_no.replace(')', '')				
				#print match_no

				# extracting day and month
				if linetemp[2].find('/') != -1 :
					day = linetemp[2].split('/')[1]
					month = linetemp[2].split('/')[0]
				else :
					day = linetemp[1]
					month = linetemp[2]
				#print day
				#print month
				
				# extracting stadium
				linetemp = line.split('@')[1]
				stadium = linetemp.split(',')[0].lower()
				stadium =stadium.replace("'","")
				
				
				#print stadium
				
				# extracting stadium address
				stadiumaddress = line.split('@')[1].split('#')[0].lower()
				stadiumaddress=stadiumaddress.replace("'","")
				
				#print stadiumaddress
				
				# extracting team1 country code
				temp1 = line.split(':')
				team1 = []
				team1new = ''
				
				if (len(temp1) == 2) :
					team1 = line.split(':')[1].split('-')[0].split()
					team1new = team1[1].lower()
					for t in team1[2:-1]:
						team1new = team1new + ' ' + t.lower()
				else :
					team1 = line.split('-')[0].split()
					team1new = team1[3].lower()
					for t in team1[4:-1]:
						team1new = team1new + ' ' + t.lower()
									
				if(country_country_code_dict.has_key(team1new)):
					team1=country_country_code_dict[team1new]
				elif(alternate_names.has_key(team1new) and country_country_code_dict.has_key(alternate_names[team1new])):
					team1=country_country_code_dict[alternate_names[team1new]]
				
				# extracting team1 score
				team1score = int(line.split('-')[0].split()[-1])
				#print team1score
				
				# extracting team2 
				team2 = []
				team2 = line.split('@')[0].split('-')[-1].split()
				team2new = team2[1].lower()
				for t in team2[2:]:
					team2new = team2new + ' ' + t.lower()					
				if(country_country_code_dict.has_key(team2new)):
					team2=country_country_code_dict[team2new]
				elif(alternate_names.has_key(team2new) and country_country_code_dict.has_key(alternate_names[team2new])):
					team2=country_country_code_dict[alternate_names[team2new]]
				#print team2
				
				# team2 score
				team2score = int(line.split('-')[1].split()[0])
				#print team2score
				
				# winner determination
				if team1score > team2score :
					winner = team1
					if setflag == 1:
						year_runnerup_winner[year] = (team1,team2)
				if team1score < team2score :
					winner = team2
					if setflag == 1:
						year_runnerup_winner[year] = (team2,team1)
				if team1score == team2score :
					winner = 'NULL'
					decision = 'DRAW'
				#print winner
				
				# decision
				if team1score != team2score :
					temp = line.split('-')[1].split()[1]
					if temp[:3] == 'pen' :
						decision = 'PENALTY'
					else :
						decision = 'WINNER'
				#print decision
				
				match_year_country.append((match_no,year,team1,team1score,decision))
				match_year_country.append((match_no,year,team2,team2score,decision))
				
				#print match_no, year
				
				stmt= 'insert into matches (Stadium, Match_Number, Winner, Decision, Team_1, Team_2, Team_1_Score, Team_2_Score, Date_Day, Date_Month, Date_Year) values (\'{0}\',{1},\'{2}\',\'{3}\',\'{4}\',\'{5}\',{6},{7},{8},\'{9}\',{10});\n'.format(stadium, match_no, winner, decision, team1, team2, team1score, team2score, day, month, year)
				print stmt

				f2=open(match_op_path, 'a')
				f2.write(stmt)    
				f2.close()
				
				if(stadium not in distinct_stadium):
					stmt= 'insert into stadium (Stadium, Stadium_Address) values (\'{0}\',\'{1}\');\n'.format(stadium,stadiumaddress)
					#stmt= '\'{0}\',\'{1}\''.format(stadium,stadiumaddress)
					print stmt
	
					f3=open(stadium_op_path, 'a')
					f3.write(stmt)    
					stmt=''
					f3.close()
					distinct_stadium.append(stadium)
				
				

			c=c+1
	#print year_runnerup_winner
	#print match_year_country
	
	return (year_runnerup_winner,match_year_country)



# This function fills goal_and_player_scores_relation
def goal_parse(match_path,goal_op_path):
	
	f2=open(goal_op_path, 'w')
	f2.truncate()  
	f2.close()
	# match_year_country_list_of_players  (It gives the list of 10 randomely selected players who are potential candidates for scoring goals)
	match_year_country_players = match_played_by_parse(match_path)
	#print match_year_country_players
	year_runnerup_winner,match_year_country = match_parse(match_path)
	matchno_year_time = list()
	for entry in match_year_country:
		#print entry
		year = entry[1]
		match_no = entry[0]
		country = entry[2]
		list_of_players = match_year_country_players[(match_no,year,country)] 
		#print entry[3]
		
		# randomly chose goal scoring times in minutes based on the number of goals scored by each team. In case of penalty the times were chosen between 120 and 130 mins
		chosen_time=list()
		for x in range(0,entry[3]) :
			if entry[4] != 'PENALTY' :
				time = random.randint(1,120)
				while(time in chosen_time or (match_no,year,time) in matchno_year_time):
					time = random.randint(1,120)
				chosen_time.append(time)
				#print time
			else:
				time = random.randint(121,130)
				while(time in chosen_time or (match_no,year,time) in matchno_year_time):
					time = random.randint(121,130)
				chosen_time.append(time)
				#print time
			
			matchno_year_time.append((match_no,year,time))
			
			num = random.randint(0,len(list_of_players)-1)
			player = list_of_players[num]
										
			stmt= 'insert into goal_and_player_scores_goals (Match_Number,Date_Year,Recorded_Time,Player_Name,Country_Code) values ({0},{1},{2},\'{3}\',\'{4}\');\n'.format(match_no,year,time,player,country)
			print stmt
			
			f2=open(goal_op_path, 'a')
			f2.write(stmt)    
			f2.close()

config = ConfigParser.RawConfigParser()
config.read('init.cfg')
match_path = config.get('dataset', 'match')
match_op_path=config.get('dataset', 'match_op')
stadium_op_path=config.get('dataset', 'stadium_op')
match_played_by_op = config.get('dataset', 'match_played_by_op')
goal_op_path=config.get('dataset', 'goal_op')

match_stadium_parse_into_table(match_path, match_op_path, stadium_op_path)
goal_parse(match_path,goal_op_path);