import ConfigParser
import os
import re
from lib import get_filepaths, getCountryCodeDict
import pprint

TEAM_PARTICIPATES_TABLE_ATTRS = ['Groups', 'Country_Code', 'Year']
TEAMS_1934 = ['Egypt', 'Austria', 'Belgium', 'Czechoslovakia', 'France', 'Germany', 'Hungary', 'Italy', 'Netherlands',
              'Romania', 'Spain', 'Sweden', 'Switzerland', 'United States', 'Argentina', 'Brazil']

TEAMS_1938 = ['Cuba', 'Poland', 'Belgium', 'Czechoslovakia', 'France', 'Germany', 'Hungary', 'Italy', 'Netherlands',
              'Romania', 'Sweden', 'Switzerland', 'Norway', 'Dutch East Indies', 'Brazil']


# This function is to hard code certain country names
def get_country_name(team_name):
    if team_name == "spain":
        return "espana"
    elif team_name == "germany":
        return "deutschland"
    elif team_name == "trinidad and tobago":
        return "trinidad tobago"
    elif team_name == "ivory coast" or team_name == "c\xc3\xb4te d'ivoire":
        return "cote d ivoire"
    elif team_name == "serbia and montenegro":
        return "serbia"
    elif team_name == "bosnia-herzegovina":
        return "bosnia herzegovina"
    else:
        return team_name

# This function parses the files and fills up the group_team_info dict
def fill_group_info(file_list, country_code_dict):
    group_team_info = {}

    for f in file_list:
        if os.path.split(f)[1] == 'cup.txt':
            year = ((os.path.split(f)[0].split("\\"))[-1].split("--"))[0]
            file_fd = open(f, 'r')
            lines = file_fd.readlines()
            for line in lines:
                if "Group" in line and "|" in line:
                    group_info = re.findall(r"\S+(?:\s\S+)*", line)
                    group_index = group_info[0].split()[1]
                    for team in group_info[2:]:
                        if team.lower() == "india":
                            # Breaks my heart doing this :(
                            continue
                        if (year, group_index) not in group_team_info:
                            group_team_info[(year, group_index)] = [country_code_dict[get_country_name(team.lower())]]
                        else:
                            group_team_info[(year, group_index)].append(
                                country_code_dict[get_country_name(team.lower())])

    return group_team_info

# This function generates the insert sql statements for the team_participates_in_world_cup table
def generate_team_participated_table_sql(group_sql, group_team_info, country_code_dict):
    sql_file = file(group_sql, 'w')
    for (year, group_index) in group_team_info:
        country_codes = group_team_info[(year, group_index)]
        for country_code in country_codes:
            insert_stmt = "INSERT INTO team_participates_in_world_cup ({0}) VALUES (\"{1}\", \"{2}\", {3});\n".format(
                ', '.join(TEAM_PARTICIPATES_TABLE_ATTRS), group_index, country_code, year)
            print insert_stmt
            sql_file.write(insert_stmt)

    # Add queries for the year 1934, 1938. (NULL groups for all participating teams)
    for team in TEAMS_1934:
        country_code = country_code_dict[get_country_name(team.lower())]
        insert_stmt = "INSERT INTO team_participates_in_world_cup ({0}) VALUES (\"{1}\", {2});\n".format(
            ', '.join(['Country_Code', 'Year']), country_code, 1934)
        print insert_stmt
        sql_file.write(insert_stmt)

    for team in TEAMS_1938:
        country_code = country_code_dict[get_country_name(team.lower())]
        insert_stmt = "INSERT INTO team_participates_in_world_cup ({0}) VALUES (\"{1}\", {2});\n".format(
            ', '.join(['Country_Code', 'Year']), country_code, 1938)
        print insert_stmt
        sql_file.write(insert_stmt)

    sql_file.close()


if __name__ == '__main__':
    config = ConfigParser.RawConfigParser()
    config.read('init.cfg')
    group_path = config.get('dataset', 'group')
    group_sql = config.get('dataset', 'group_op')

    country_code_dict = getCountryCodeDict()
    file_list = get_filepaths(group_path)
    group_team_info = fill_group_info(file_list, country_code_dict);
    #pprint.pprint(group_team_info)
    generate_team_participated_table_sql(group_sql, group_team_info, country_code_dict);




