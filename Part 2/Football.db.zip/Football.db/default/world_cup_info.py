import ConfigParser
import os
import re
from lib import get_filepaths, match_parse, match_filepaths
import pprint


# Run squad_info before running this

WORLD_CUP_TABLE_ATTRS = ['Year', 'Host_Country', 'Winner', 'Runner_Up']


def fill_wc_info(file_list):
    year_host_info = {}

    for f in file_list:
        if os.path.split(f)[1] == 'cup.txt':
            year = ((os.path.split(f)[0].split("\\"))[-1].split("--"))[0]
            file_fd = open(f, 'r')
            lines = file_fd.readlines()
            host_country = ''
            for line in lines:
                if "World Cup" in line:
                    tokens = line.split()
                    name_tokens = []
                    for t in tokens[4:]:
                        if not re.search('[a-zA-Z]', t):
                            break
                        else:
                            name_tokens.append(re.sub(r'\W+', '', t))

                    host_country = ' '.join(name_tokens)
                    break

            year_host_info[year] = host_country

    return year_host_info

# This function generates the insert SQL statements for the WORLD_CUP table
def generate_world_cup_table_sql(wc_sql, year_host_info,match_path):
    (year_runnerup_winner, match_year_country) = match_parse(match_path)
    sql_file = file(wc_sql, 'w')
    for year in year_host_info:
        winner = year_runnerup_winner[year][0]
        runner_up = year_runnerup_winner[year][1]
        host = year_host_info[year]
        insert_stmt = "INSERT INTO  world_cup ({0}) VALUES ({1}, \"{2}\", \"{3}\", \"{4}\");\n".format(
            ', '.join(WORLD_CUP_TABLE_ATTRS), year, host, winner, runner_up)
        sql_file.write(insert_stmt)

    sql_file.close()


if __name__ == '__main__':
    config = ConfigParser.RawConfigParser()
    config.read('init.cfg')
    wc_path = config.get('dataset', 'worldcup')
    wc_sql = config.get('dataset', 'worldcup_op')
    match_path = config.get('dataset', 'match')

    file_list = get_filepaths(wc_path)
    year_host_info = fill_wc_info(file_list);
    pprint.pprint(year_host_info)
    generate_world_cup_table_sql(wc_sql, year_host_info,match_path);




