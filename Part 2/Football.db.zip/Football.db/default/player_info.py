import ConfigParser
import os
import re
from random import randrange, choice
from datetime import datetime
import pickle
from lib import get_filepaths, fill_squad_info


PLAYER_TABLE_TUPLES = ['Country_Code', 'Player_Role', 'Player_Name', 'DOB', 'Jersey_Number', 'Club']
WORLD_CUP_PLAYED_BY_TABLE_TUPLES = ['Year', 'Player_Name', 'Country_Code']

# This function generates the insert sql statements for the Player table and the
# world_cup_played_by_player table
def generate_player_table_sql(player_info_dict, year_played_dict):
    sql_file_1 = file(player_sql, 'w')
    sql_file_2 = file(worldcup_played_sql, 'w')

    for player_name, country_code in player_info_dict:        
        player_role = player_info_dict[(player_name,country_code)][1]
        DOB = player_info_dict[(player_name,country_code)][2]
        jersey_no = player_info_dict[(player_name,country_code)][3]
        club = player_info_dict[(player_name,country_code)][4]
        
        insert_stmt = "INSERT INTO player ({0}) VALUES (\"{1}\", \"{2}\", \"{3}\", {4}, {5}, \"{6}\");\n".format(
            ', '.join(PLAYER_TABLE_TUPLES), country_code, player_role, player_name, DOB, jersey_no, club)     
        #print insert_stmt   
        
        sql_file_1.write(insert_stmt)

    for year in year_played_dict:
        players_country_list = year_played_dict[year]
        for pl_name, country_code in players_country_list:
            insert_stmt = "INSERT INTO world_cup_played_by_player ({0}) VALUES ({1}, \"{2}\", \"{3}\");\n".format(
            ', '.join(WORLD_CUP_PLAYED_BY_TABLE_TUPLES), year, pl_name, country_code)
            sql_file_2.write(insert_stmt)
            #print insert_stmt

    sql_file_1.close()
    sql_file_2.close()


if __name__ == '__main__':
    config = ConfigParser.RawConfigParser()
    config.read('init.cfg')
    player_path = config.get('dataset', 'player')
    
    player_sql = config.get('dataset', 'player_op')
    worldcup_played_sql = config.get('dataset', 'worldcup_played_by_op')

    
    country_code_dict, player_info_dict, players_dict, goal_keepers_dict, year_played_dict = fill_squad_info(player_path);
    generate_player_table_sql(player_info_dict, year_played_dict);

    # Dump the country code dict to a pickle file
    with open('country_code.pickle', 'wb') as handle:
        pickle.dump(country_code_dict, handle)