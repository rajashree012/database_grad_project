import ConfigParser
import random
from lib import match_parse, fill_squad_info
import pprint

#correlated data of players and matches each year
def match_played_by_parse_into_table(match_path, match_op_path):
    #get player info for each year
    country_code_dict, player_info_dict, players_dict, goal_keepers_dict, year_player_dict = fill_squad_info(match_path)
    #get matches played in each year
    (year_runnerup_winner,match_year_country)=match_parse(match_path)
    
    match_year_country_players=dict()
    
    f2=open(match_played_by_op, 'w')
    f2.truncate()  
    f2.close()
    
    for x in match_year_country:
        match_no=x[0]
        year=x[1]
        team1=x[2]
        if(players_dict.has_key((year,team1)) and goal_keepers_dict.has_key((year,team1))):
            players=players_dict[(year,team1)]
            goalkeepers=goal_keepers_dict[(year,team1)]
            #extracting 10 random players among squad that match
            ten_players=random.sample(players,10)
           
            #extracting 1 random goal keeper among squad that match
            match_year_country_players[match_no,year,team1]=ten_players
            one_goalkeeper=random.sample(goalkeepers,1)
            
           
            for player in ten_players:
                stmt= 'insert into match_played_by (Match_Number, Date_Year, Country_Code, Player_Name) values ({0},{1},\'{2}\',\'{3}\');\n'.format(match_no, year, team1, player)
               
                f2=open(match_played_by_op, 'a')
                f2.write(stmt)    
                f2.close()
                
            for keeper in one_goalkeeper:
                stmt= 'insert into match_played_by (Match_Number, Date_Year, Country_Code, Player_Name) values ({0},{1},\'{2}\',\'{3}\');\n'.format(match_no, year, team1, keeper)
               
                f2=open(match_played_by_op, 'a')
                f2.write(stmt)    
                f2.close()
               
    return match_year_country_players    
     

config = ConfigParser.RawConfigParser()
config.read('init.cfg')
match_path=config.get('dataset', 'match')
match_played_by_op = config.get('dataset', 'match_played_by_op')


match_played_by_parse_into_table(match_path, match_played_by_op)