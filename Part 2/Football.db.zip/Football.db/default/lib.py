import pickle
import os
from random import randrange, choice
from datetime import datetime
import re
import random
import pprint

# This function loads the country_code_dict from the stored pickle file
def getCountryCodeDict():
    with open('country_code.pickle', 'rb') as f:
        country_code_dict = pickle.load(f)
    return country_code_dict

def get_filepaths(directory):
    file_paths = []
    for root, directories, files in os.walk(directory):
        for filename in files:
            filepath = os.path.join(root, filename)
            file_paths.append(filepath)
    return file_paths

def get_player_role(tokens):
    return tokens[1]

# We are generating a random date of birth for each player. The players are always in the
# age range 20-30
def generate_random_date(year):
    date_year = choice(range(int(year) - 30, int(year) - 20))
    date_month = choice(range(1, 12))
    date_day = choice(range(1, 28))
    DOB = datetime(date_year, date_month, date_day)
    return DOB


def get_player_jersey(tokens):
    s = tokens[0]
    jersey_number = s[s.find("(") + 1:s.find(")")]
    if jersey_number.isdigit():
        return jersey_number
    else:
        jersey_number = randrange(1, 30)
        return jersey_number
    return None


def get_player_club(tokens):
    hash_index = tokens.index('##')
    club_name = ' '.join(tokens[hash_index + 2:])
    return club_name

# This function parses the squad files and fills the player and country_code_dict, players_dict,
# goal_keepers_dict, player_info_dict and the year_player_dict
def fill_squad_info(player_path):
    
    file_list = get_filepaths(player_path)
    country_code_dict = {}
    players_dict = {}  # This dict is a (year, country) to list of players map
    goal_keepers_dict = {}  # This dict is a (year, country) to list of goalkeepers map
    player_info_dict = {}  # This dict is a player name to player details map
    year_player_dict = {}  # This dict is a map from year to a list of (player name, country code)

    for f in file_list:
        if '\\squads\\' in f:
            tokens = os.path.split(f)

            year = ((tokens[0].split("\\"))[-2].split("--"))[0]

            # Split the file name (of the form x-y.txt, where x is the country code and y is the country name
            file_name = tokens[1]
            file_name = file_name.replace('-', '.')

            country_tokens = file_name.split('.')
            country_code = country_tokens[0].upper()
            country_name_tokens = []
            for t in country_tokens[1:]:
                if t != "txt":
                    country_name_tokens.append(t)
            country_name = ' '.join(country_name_tokens)
            if country_name not in country_code_dict:
                country_code_dict[country_name] = country_code

            # Fill the goal keepers and players dict

            goal_keepers_in_team = []
            players_in_team = []

            file_fd = open(f, 'r')
            lines = file_fd.readlines()
            positions = ['GK', 'MF', 'FW', 'DF']
            for line in lines:
                if any(position in line for position in positions):
                    tokens = line.split()

                    player_country_code = country_code
                    player_role = get_player_role(tokens)
                    player_date_of_birth = generate_random_date(year)
                    player_jersey_number = get_player_jersey(tokens)
                    player_club = get_player_club(tokens)

                    pData = [player_country_code, player_role, player_date_of_birth.strftime("%Y-%m-%d"),
                             player_jersey_number, player_club]

                    name_tokens = []
                    for t in tokens[2:]:
                        if not re.search('[a-zA-Z]', t):
                            break
                        else:
                            name_tokens.append(re.sub(r'\W+', '', t))

                    player_name = ' '.join(name_tokens)
                    #players_in_team.append(player_name)

                    if player_name == '':
                        continue

                    player_info_dict[(player_name, player_country_code)] = pData

                    if 'GK' in line:
                        goal_keepers_in_team.append(player_name)
                    else:
                        players_in_team.append(player_name)

                    if year not in year_player_dict:
                        year_player_dict[year] = [(player_name, player_country_code)]
                    else:
                        year_player_dict[year].append((player_name, player_country_code))

            if (year, country_code) not in goal_keepers_dict:
                goal_keepers_dict[(year, country_code)] = goal_keepers_in_team

            if (year, country_code) not in players_dict:
                players_dict[(year, country_code)] = players_in_team

    
    return country_code_dict, player_info_dict, players_dict, goal_keepers_dict, year_player_dict


# getting cup.txt and cup_finals.txt
def match_filepaths(path):
    full_file_paths = get_filepaths(path);
    selected_file_paths = []
    for f in full_file_paths:
        if f.split('\\')[-1] == 'cup.txt' or f.split('\\')[-1] == 'cup_finals.txt' : 
            selected_file_paths.append(f)
    return selected_file_paths

# filling the match table
def match_parse(match_path):
	# loading country codes for country name into dictionary from pickle dump
    country_country_code_dict = getCountryCodeDict()
	# These are few exception cases
    alternate_names=dict()
    alternate_names['germany']='deutschland'
    alternate_names['trinidad and tobago']='trinidad tobago'
    alternate_names['spain']='espana'
    alternate_names['c te d ivoire']='cote d ivoire'
    alternate_names['c\xc3\xb4te d\'ivoire']='cote d ivoire'
    alternate_names['serbia and montenegro']='serbia'
    alternate_names['bosniaherzegovina'] = 'bosnia herzegovina'
    
    
    
    # create dictionary for year : (winner,runnerup)
    year_runnerup_winner = {}

    # create list of (match_no,year,country_code, country_score,decision)
    match_year_country = []
    for path in match_filepaths(match_path) :
        f=open(path, 'r')          
        lines= f.readlines()
        f.close() 
        
        # choosing the starting point in the file different for cup.txt and cup_finals.txt
        start=0;
        c=0;
        
        if path.split('\\')[-1] == 'cup.txt' :
            for line in lines:
                if(line.strip().startswith('(1)')):
                    start=c;
                    break;
                c=c+1 
            
        if path.split('\\')[-1] == 'cup_finals.txt' :
            for line in lines:
                if(line.strip().startswith('(')):
                    start=c;
                    break;
                c=c+1 
        #print path
        # extracting year
        if len(path.split('\\')) > 0 :
            year = path.split('\\')[-2].split('-')[0]
            
        else :
            year = path.split('/')[-2].split('-')[0]
            
        setflag = 0
        c = 0
        # start processing each line
        for line in lines:
            line = line.rstrip('\n')
            # trying to find winner and runner up for an year
            if line.startswith('final') or line.startswith('Final'):
                setflag = 1
            if(c>= start and line.startswith('(')):
                
                linetemp=line.split();
                
                # extracting match number
                match_no = linetemp[0]
                match_no = match_no.replace('(', '')
                match_no = match_no.replace(')', '')                
                #print match_no

                # extracting day and month
                if linetemp[2].find('/') != -1 :
                    day = linetemp[2].split('/')[1]
                    month = linetemp[2].split('/')[0]
                else :
                    day = linetemp[1]
                    month = linetemp[2]
                #print day
                #print month
                
                # extracting stadium
                linetemp = line.split('@')[1]
                stadium = linetemp.split(',')[0]
                #print stadium
                
                # extracting stadium address
                stadiumaddress = line.split('@')[1].split('#')[0]
                #print stadiumaddress
                
                # extracting team1 country code
                temp1 = line.split(':')
                team1 = []
                team1new = ''
                
                if (len(temp1) == 2) :
                    team1 = line.split(':')[1].split('-')[0].split()
                    team1new = team1[1].lower()
                    for t in team1[2:-1]:
                        team1new = team1new + ' ' + t.lower()
                else :
                    team1 = line.split('-')[0].split()
                    team1new = team1[3].lower()
                    for t in team1[4:-1]:
                        team1new = team1new + ' ' + t.lower()
                                    
                if(country_country_code_dict.has_key(team1new)):
                    team1=country_country_code_dict[team1new]
                elif(alternate_names.has_key(team1new) and country_country_code_dict.has_key(alternate_names[team1new])):
                    team1=country_country_code_dict[alternate_names[team1new]]
                
                # extracting team1 score
                team1score = int(line.split('-')[0].split()[-1])
                #print team1score
                
                # extracting team2 country_code
                team2 = []
                team2 = line.split('@')[0].split('-')[-1].split()
                team2new = team2[1].lower()
                for t in team2[2:]:
                    team2new = team2new + ' ' + t.lower()                    
                if(country_country_code_dict.has_key(team2new)):
                    team2=country_country_code_dict[team2new]
                elif(alternate_names.has_key(team2new) and country_country_code_dict.has_key(alternate_names[team2new])):
                    team2=country_country_code_dict[alternate_names[team2new]]
                #print team2
                
                # extracting team2 score
                team2score = int(line.split('-')[1].split()[0])
                #print team2score
                
                # winner determination
                if team1score > team2score :
                    winner = team1
                    if setflag == 1:
                        year_runnerup_winner[year] = (team1,team2)
                if team1score < team2score :
                    winner = team2
                    if setflag == 1:
                        year_runnerup_winner[year] = (team2,team1)
                if team1score == team2score :
                    winner = 'NULL'
                    decision = 'DRAW'
                #print winner
                
                # decision
                if team1score != team2score :
                    temp = line.split('-')[1].split()[1]
                    if temp[:3] == 'pen' :
                        decision = 'PENALTY'
                    else :
                        decision = 'WINNER'
                #print decision
                
                match_year_country.append((match_no,year,team1,team1score,decision))
                match_year_country.append((match_no,year,team2,team2score,decision))
                
                
            c=c+1
    #print year_runnerup_winner
    #print match_year_country
    return (year_runnerup_winner,match_year_country)


def match_played_by_parse(match_path):
    
    
    country_code_dict, player_info_dict, players_dict, goal_keepers_dict, year_player_dict = fill_squad_info(match_path)
    year_runnerup_winner,match_year_country=match_parse(match_path)
    
    match_year_country_players=dict()
    
    for x in match_year_country:
        
        match_no=x[0]
        year=x[1]
        team1=x[2]
        if(players_dict.has_key((year,team1)) and goal_keepers_dict.has_key((year,team1))):
            players=players_dict[(year,team1)]
            goalkeepers=goal_keepers_dict[(year,team1)]
            ten_players=random.sample(players,10)
            
            match_year_country_players[match_no,year,team1]=ten_players
            one_goalkeeper=random.sample(goalkeepers,1)
            
    return match_year_country_players    