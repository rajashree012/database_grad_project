import ConfigParser
import re
import lib

#Add countries that do not have ranking and point info
def fillAdditonalInfo(dynamic_country_list,country_code_dict,country_assoc):
   
    for (country_name, country_code) in country_code_dict.iteritems():        
        if(dynamic_country_list.count(country_name)==0):
            association=''
            if country_assoc.has_key(country_name):
                association=country_assoc[country_name]
                
            stmt= 'insert into team (Country_Code, Country_Name, Association) values (\'{0}\',\'{1}\',\'{2}\');\n'.format(country_code, country_name, association)
                
            f2=open(team_op_path, 'a')
            f2.write(stmt)    
            f2.close()
  
#parse country statistics and also extract association and country code
def world_cup_parse(team_path,team_op_path, country_assoc_path): 
    
    #fixing some country names spelled differently
    alternate_names=dict()
    alternate_names['germany']='deutschland'
    alternate_names['trinidad and tobago']='trinidad tobago'
    alternate_names['spain']='espana'
    alternate_names['c te d ivoire']='cote d ivoire'     
        
    #get country code
    country_code_dict = lib.getCountryCodeDict()
    
    dynamic_country_list = list()
    
    f=open(team_path, 'r')          
    lines= f.readlines()
    f.close() 
    
    f3=open(country_assoc_path, 'r')          
    a_lines= f3.readlines()
    f3.close() 
    
    f2=open(team_op_path, 'w')
    f2.truncate()  
    f2.close()
    
    
    country_assoc=dict()
    
    #extract country name and country association info
    for a_line in a_lines:
        country=a_line.split(',')[0].strip()
        assoc=a_line.split(',')[1].strip()
        country_assoc[country]=assoc
            
    start=0;
    c=0;
    for line in lines:
        if(line.strip().startswith('1 ')):
            start=c;
            break;
        c=c+1    
    
    c=0;   
    #extract country name, ranking and points info  
    for line in lines:
        if(c>= start):
            line=line.strip();
            
            t=re.split('[^a-zA-Z0-9_()]',line)            
            t= filter(None, t)   
            
            i=0
            team=' '
                        
            for token in t:
                if(i==0):                    
                    i=i+1  
                    continue
                if(token.startswith('(')):                                        
                    break                
                team= team+" "+token
                i=i+1  
                  
            ranking=t[3+(i-2)]            
            points=t[9+(i-2)]
            
            team=team.lstrip().lower()
                       
            if(country_code_dict.has_key(team)):
                teamcode=country_code_dict[team]
            elif(alternate_names.has_key(team) and country_code_dict.has_key(alternate_names[team])):
                teamcode=country_code_dict[alternate_names[team]]
                team=alternate_names[team]
                
            else:                
                continue
            
            dynamic_country_list.append(team)
            
            if country_assoc.has_key(team):
                association=country_assoc[team]
                stmt= 'insert into team (Country_Code, Country_Name,Association, Points, Ranking) values (\'{0}\',\'{1}\',\'{2}\',{3},{4});\n'.format(teamcode, team,association,points, ranking)
            else:
                stmt= 'insert into team (Country_Code, Country_Name, Points, Ranking) values (\'{0}\',\'{1}\',{2},{3});\n'.format(teamcode, team,points, ranking)
            
            f2=open(team_op_path, 'a')
            f2.write(stmt)    
            f2.close()
            
                  
        c=c+1
    
    fillAdditonalInfo(dynamic_country_list,country_code_dict,country_assoc)
          

config = ConfigParser.RawConfigParser()
config.read('init.cfg')
team_path = config.get('dataset', 'team')
team_op_path=config.get('dataset', 'team_op')
country_assoc_path= config.get('dataset', 'country_assoc')
    
world_cup_parse(team_path, team_op_path,country_assoc_path)
        
